import { useEffect, useState } from "react";
import { BiConfused } from "react-icons/bi";
import { TbGridDots } from "react-icons/tb";

export default function () {
  const [items, setItems] = useState([
    {
      id: 1,
      text: "text-1",
      icon: <BiConfused />,
      outText: "3x",
    },
    {
      id: 2,
      text: "text-2",
      icon: <BiConfused />,
      outText: "5x",
    },
    {
      id: 3,
      text: "text-3",
      icon: <BiConfused />,
      outText: "4x",
    },
    {
      id: 4,
      text: "text-4",
      icon: <BiConfused />,
      outText: "NA",
    },
    {
      icon: <TbGridDots />,
    },
  ]);

  const [showNum, setShowNum] = useState(null);
  const showHandler = (e) => {
    if (showNum === e) {
      setShowNum(null);
    } else {
      setShowNum(e);
    }
  };

  useEffect(() => {
    const cItems = document.querySelectorAll(".dragd-menu-item");
    for (let i = 0; i < cItems.length; i++) {
      cItems[i].style.transform = `rotate(${
        i * (360 / cItems.length) + 115
      }deg) translate(50%, 50%)`;
      cItems[4].style.zIndex = "1";
    }
  }, []);
  return (
    <ul className="dragd-menu">
      {items &&
        items.map((item, i) => (
          <li key={i} className="dragd-menu-item">
            <a
              onClick={(e) => showHandler(item.id)}
              className={`dragd-menu-link ${(!item.text && "picker") || ""}`}
            >
              <span>{item.icon && item.icon}</span>
              <span>{item.text && item.text}</span>
            </a>
            <p
              className={`dragd-menu-outer ${
                (item.id === showNum && "show") || ""
              }`}
            >
              {item.outText && item.outText}
            </p>
          </li>
        ))}
      <div className="dragd-menu-inner">
        <span>
          {" "}
          <BiConfused />
        </span>
        <span> Text </span>
      </div>
    </ul>
  );
}
